# Translations

Obtiene las cadenas de texto y las urls de imagenes de la aplicación.
