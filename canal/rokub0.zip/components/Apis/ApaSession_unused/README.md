# APA Session

Fuerza actualizacion de sesion en el servidor.

No devuelve ningun dato útil.

Sirve para que el usuario sea direccionado hacia la partición correspondiente. Se utiliza en el login e isloggedin, teniendo en cuenta que el usuario anonimo puede caer en una partición aunque luego de iniciar sesión el id de usuario pertenezca a una diferente. Se realiza el llamado y el backend se encarga de la redirección.
