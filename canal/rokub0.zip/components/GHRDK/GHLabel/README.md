# GHLabel

## Propiedades

| Nombre      | Tipo    | Default  | Descripción |
| ----------- | ------- | -------- | ----------- |
| text        | string  | MyLabel  |             |
| translation | string  | [0,0]    |             |
| width       | string  | 0        |             |
| height      | string  | 0        |             |
| horizAlign  | string  | center   |             |
| vertAlign   | string  | center   |             |
| color       | string  | 0x000000 |             |
| selColor    | string  | 0xFFFFFF |             |
| focus       | boolean | false    |             |
| selected    | boolean | false    |             |
| value       | string  | mybutton |             |
| debug       | boolean | false    |             |

## Ejemplo

Declaración del grupo en el xml.

```xml

```

Manejo del componente.

```basic

```



