# GHRDK Utilidades
