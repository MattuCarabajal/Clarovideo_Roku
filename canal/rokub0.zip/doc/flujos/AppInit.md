# APP Init

Flujo de comienzo de aplicación.
**Inicia por el `[FLUJO_HKS]`**

![app_api_init](img/app_api_init.png)

---

## Flujo HKS

**`[NO_HKS]` Si NO tengo el HKS**

- llamo a la startHeaderInfo: devuelve el HKS y la region
- llamo al APA/metadata y APA/asset
- muestro las pantallas
- Hago el flujo de login >> actualizo la registry

**`[SI_HKS]` SI tengo el HKS**

- no llamo a la startHeaderInfo
- llamo a la isLoggedIn _hace un login_ >> PUSH_SESSION

## Flujo LOGGED

**`[NO_LOGGED]` Si no esta logeado**

- llamo a la starHeaderInfo
- llamo al APA/metadata y APA/asset
- Hago el flujo de login >> actualizo la registry >> PUSH_SESSION
- llamo al APA/metadata y APA/asset

**`[SI_LOGGED]` Si está logeado**

- llamo al APA/metadata y APA/asset
- lo mando a la home

---

### OTROS PARA MAS ADELANTE

**APA/launcher**

- appversion, osversion, apfirmware (actualizacion?)
- SumoLogic (loggeo de aplicacion)

---

### PROBLEMAS

- el APA si no tiene la region no devuelve nada.

---
