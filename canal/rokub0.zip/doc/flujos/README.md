# Flujos de Aplicación

- [Flujo de inicio de aplicación](AppInit.md)
